<x-app-layout>
 <div>Index of ideas index</div>
</x-app-layout> 

