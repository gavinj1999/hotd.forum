<x-app-layout>
    <div>Index of ideas Forum</div>
   </x-app-layout>
   
   