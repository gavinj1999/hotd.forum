<x-app-layout>
<livewire:ideas-index/>
</x-app-layout>