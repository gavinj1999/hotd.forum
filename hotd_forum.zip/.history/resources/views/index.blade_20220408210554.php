<x-app-layout>
<div class="filters flex space-x-6">
    <div class="w-1">
    <div>
        <select name="category" id="category" class="w-full rounded-xl px-4 py-2">

        </select>
    </div>


</div>
</x-app-layout> 

