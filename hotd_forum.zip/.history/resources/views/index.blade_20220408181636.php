<x-app-layout>
 <div>Index of ideas</div>
</x-app-layout>

