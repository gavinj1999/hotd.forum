<?php

namespace App\Http\Livewire;

use Livewire\Component;

class StatusFilters extends Component
{
    public function render()
    {
        return view('livewire.status-filters');
    }
}
